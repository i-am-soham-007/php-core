<html>
<head>
    <link rel="stylesheet" href="datatables.min.css">
    <link rel="stylesheet" href="dataTables.checkboxes.css">
</head>
<body>
<form id="form" method="POST">
<input type="submit" name="block" class="btn btn-danger" value="Block">
<input type="submit" name="unblock" class="btn btn-primary" value="Unblock">
</form>
    <table id="example" class="display" cellspacing="0" width="100%">
   <thead>
      <tr>
         <th></th>
         <th>Name</th>
         <th>Position</th>
         <th>Office</th>
         <th>Extn.</th>
         <th>Start date</th>
         <th>Salary</th>
      </tr>
   </thead>
   <tfoot>
      <tr>
         <th></th>
         <th>Name</th>
         <th>Position</th>
         <th>Office</th>
         <th>Extn.</th>
         <th>Start date</th>
         <th>Salary</th>
      </tr>
   </tfoot>
</table>
</body>
</html>
<script src="jquery.min.js"></script>
<script src="datatables.min.js"></script>
<script src="dataTables.checkboxes.min.js"></script>
<script>
$(document).ready(function (){
   var table = $('#example').DataTable({
      'ajax': 'demo.txt',
      'columnDefs': [
         {
            'targets': 0,
            'checkboxes': {
               'selectRow': true
            }
         }
      ],
      'select': {
         'style': 'multi'
      },
      'order': [[1, 'asc']]
   });


   // Handle form submission event
   $('#form').on('submit', function(e){
      var form = this;
      var rows_selected = table.column(0).checkboxes.selected();
      // Iterate over all selected checkboxes
      $.each(rows_selected, function(index, rowId){
         // Create a hidden element
         $(form).append(
             $('<input>')
                .attr('type', 'hidden')
                .attr('name', 'id[]')
                .val(rowId)
         );
      });
      //console.log(form);
   });
});
</script>

<?php
if(isset($_POST['block']))
{
   // echo "block run";
    extract($_POST);
    print_r($id);

}

?>